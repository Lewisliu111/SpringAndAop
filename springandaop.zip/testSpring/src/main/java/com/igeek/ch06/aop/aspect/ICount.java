package com.igeek.ch06.aop.aspect;

//计算器接口
public interface ICount {

    public int add(int a, int b);
    public int sub(int a, int b);
    public int mul(int a, int b);
    public int div(int a, int b);

}
