package com.igeek.ch07.trans.exception;

public class BookStockException extends  Exception {

    public BookStockException() {
    }

    public BookStockException(String message) {
        super(message);
    }
}
