package com.igeek.ch04.annotation.dao;

public interface IDao {

    public void select();

}
